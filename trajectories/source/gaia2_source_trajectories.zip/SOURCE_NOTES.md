# Source trajectories

This archive retains the supplied HTML/TXT layout, source event ordering, system configurations, tool calls and observations, errors, and evaluation results. It has not been converted to the configuration-history presentation.

Publication filtering covers identifying metadata, host-local paths, known personal identifiers, credential patterns, and provider support contact details. Repeated exact paths use stable placeholders. Benchmark scenario data and task identities are retained. File timestamps and permission metadata are normalized for distribution.

This is not the byte-for-byte original archive. Unmodified originals remain outside the public repository. The manifest identifies changed files. Redaction patterns are practical checks, not a guarantee against every possible indirect identifier.
