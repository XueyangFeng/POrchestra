# Source trajectories

384 task trajectories across three rounds in HTML and TXT format.

Open `gaia2_porch/index.html` to browse by round. Each task includes system configurations, tool calls, observations, execution errors, and evaluation results.
